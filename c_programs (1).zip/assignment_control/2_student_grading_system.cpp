#include <iostream>
using namespace std;

int main()
{
    int marks[5], failCount = 0, total = 0;
    float percentage;

    for (int i = 0; i < 5; i++)
    {
        cout << "Enter marks for subject " << i + 1 << ": ";
        cin >> marks[i];
        total += marks[i];

        if (marks[i] < 40)
            failCount++;
    }

    percentage = (total / 500.0) * 100;
    cout << "Percentage: " << percentage << "%" << endl;

    if (failCount > 1)
    {
        cout << "Repeat Year" << endl;
    }
    else
    {
        if (percentage >= 90)
        {
            cout << "Grade: A" << endl;
        }
        else
        {
            if (percentage >= 75)
            {
                cout << "Grade: B" << endl;
            }
            else
            {
                if (percentage >= 60)
                {
                    cout << "Grade: C" << endl;
                }
                else
                {
                    if (percentage >= 40)
                        cout << "Grade: D" << endl;
                    else
                        cout << "Grade: F" << endl;
                }
            }
        }
    }

    return 0;
}
