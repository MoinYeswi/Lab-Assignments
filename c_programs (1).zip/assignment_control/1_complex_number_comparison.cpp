#include <iostream>
#include <cmath>
using namespace std;

int main()
{
    double r1, i1, r2, i2, mag1, mag2;

    cout << "Enter real and imaginary part of first complex number: ";
    cin >> r1 >> i1;
    cout << "Enter real and imaginary part of second complex number: ";
    cin >> r2 >> i2;

    mag1 = sqrt(r1 * r1 + i1 * i1);
    mag2 = sqrt(r2 * r2 + i2 * i2);

    cout << "Magnitude of first: " << mag1 << endl;
    cout << "Magnitude of second: " << mag2 << endl;

    if (mag1 > mag2)
        cout << "First complex number has higher magnitude" << endl;
    else if (mag2 > mag1)
        cout << "Second complex number has higher magnitude" << endl;
    else
        cout << "Equal" << endl;

    return 0;
}
