#include <iostream>
using namespace std;

int main()
{
    double a, b;
    char op;

    cout << "Enter first operand: ";
    cin >> a;
    cout << "Enter operator (+, -, *, /, %): ";
    cin >> op;
    cout << "Enter second operand: ";
    cin >> b;

    int valid = (op == '+' || op == '-' || op == '*' || op == '/' || op == '%');

    if (!valid)
    {
        cout << "Error: invalid operator" << endl;
        return 0;
    }

    if ((op == '/' || op == '%') && b == 0)
    {
        cout << "Error: division by zero" << endl;
        return 0;
    }

    double result = (op == '+') ? (a + b) :
                     (op == '-') ? (a - b) :
                     (op == '*') ? (a * b) :
                     (op == '/') ? (a / b) :
                     (int)a % (int)b;

    cout << "Result = " << result << endl;

    return 0;
}
