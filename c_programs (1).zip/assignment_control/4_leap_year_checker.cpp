#include <iostream>
using namespace std;

bool isLeap(int year)
{
    if (year % 4 == 0)
    {
        if (year % 100 == 0)
        {
            if (year % 400 == 0)
                return true;
            else
                return false;
        }
        else
        {
            return true;
        }
    }
    else
    {
        return false;
    }
}

int main()
{
    int year;

    cout << "Enter a year: ";
    cin >> year;

    if (isLeap(year))
    {
        cout << year << " is a leap year" << endl;
    }
    else
    {
        cout << year << " is not a leap year" << endl;
        cout << "Next 5 leap years: ";

        int y = year + 1, count = 0;
        while (count < 5)
        {
            if (isLeap(y))
            {
                cout << y << " ";
                count++;
            }
            y++;
        }
        cout << endl;
    }

    return 0;
}
