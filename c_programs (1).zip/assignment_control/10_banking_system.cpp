#include <iostream>
using namespace std;

int main()
{
    double balance = 0;
    int choice;

    do
    {
        cout << "\n----- Bank Menu -----" << endl;
        cout << "1. Deposit" << endl;
        cout << "2. Withdraw" << endl;
        cout << "3. Balance Inquiry" << endl;
        cout << "4. Exit" << endl;
        cout << "Enter your choice: ";
        cin >> choice;

        switch (choice)
        {
            case 1:
            {
                double amount;
                cout << "Enter amount to deposit: ";
                cin >> amount;

                if (amount <= 0)
                    cout << "Invalid deposit amount" << endl;
                else
                {
                    balance += amount;
                    cout << "Deposit successful. New balance: " << balance << endl;
                }
                break;
            }

            case 2:
            {
                double amount;
                cout << "Enter amount to withdraw: ";
                cin >> amount;

                if (amount <= 0)
                    cout << "Invalid withdrawal amount" << endl;
                else if (amount > balance)
                    cout << "Insufficient balance" << endl;
                else
                {
                    balance -= amount;
                    cout << "Withdrawal successful. New balance: " << balance << endl;
                }
                break;
            }

            case 3:
                cout << "Current balance: " << balance << endl;
                break;

            case 4:
                cout << "Exiting... Thank you" << endl;
                break;

            default:
                cout << "Invalid choice, try again" << endl;
        }

    } while (choice != 4);

    return 0;
}
