#include <iostream>
using namespace std;

bool isPalindrome(int num)
{
    int original = num, rev = 0;

    while (num != 0)
    {
        rev = rev * 10 + num % 10;
        num = num / 10;
    }

    return (rev == original);
}

int main()
{
    int num, low, high;

    cout << "Enter a number to check: ";
    cin >> num;

    if (isPalindrome(num))
        cout << num << " is a palindrome" << endl;
    else
        cout << num << " is not a palindrome" << endl;

    cout << "Enter a range to find palindromes (low high): ";
    cin >> low >> high;

    cout << "Palindrome numbers in range: ";
    for (int i = low; i <= high; i++)
    {
        if (isPalindrome(i))
            cout << i << " ";
    }
    cout << endl;

    return 0;
}
