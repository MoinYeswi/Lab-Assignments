#include <iostream>
#include <cmath>
using namespace std;

int main()
{
    double a, b, c;

    cout << "Enter coefficients a, b, c: ";
    cin >> a >> b >> c;

    if (a == 0)
    {
        cout << "Coefficient a cannot be zero, this is not a quadratic equation" << endl;
        return 0;
    }

    double disc = b * b - 4 * a * c;

    if (disc > 0)
    {
        double root1 = (-b + sqrt(disc)) / (2 * a);
        double root2 = (-b - sqrt(disc)) / (2 * a);
        cout << "Roots are real and distinct" << endl;
        cout << "Root1 = " << root1 << endl;
        cout << "Root2 = " << root2 << endl;
    }
    else if (disc == 0)
    {
        double root = -b / (2 * a);
        cout << "Roots are real and equal" << endl;
        cout << "Root = " << root << endl;
    }
    else
    {
        double realPart = -b / (2 * a);
        double imagPart = sqrt(-disc) / (2 * a);
        cout << "Roots are imaginary" << endl;
        cout << "Root1 = " << realPart << " + " << imagPart << "i" << endl;
        cout << "Root2 = " << realPart << " - " << imagPart << "i" << endl;
    }

    return 0;
}
