#include <iostream>
using namespace std;

bool isLeapYear(int year)
{
    return (year % 4 == 0 && (year % 100 != 0 || year % 400 == 0));
}

int main()
{
    int day, month, year;

    cout << "Enter date (DD MM YYYY): ";
    cin >> day >> month >> year;

    int daysInMonth[] = {31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31};

    if (isLeapYear(year))
        daysInMonth[1] = 29;

    bool valid = true;

    if (month < 1 || month > 12)
        valid = false;
    else if (day < 1 || day > daysInMonth[month - 1])
        valid = false;
    else if (year < 1)
        valid = false;

    if (!valid)
    {
        cout << "Invalid date" << endl;
        return 0;
    }

    cout << "Valid date" << endl;

    // Zeller's congruence to find day of week
    int d = day, m = month, y = year;
    if (m < 3)
    {
        m += 12;
        y -= 1;
    }

    int k = y % 100;
    int j = y / 100;
    int h = (d + (13 * (m + 1)) / 5 + k + k / 4 + j / 4 + 5 * j) % 7;

    switch (h)
    {
        case 0:
            cout << "Day: Saturday" << endl;
            break;
        case 1:
            cout << "Day: Sunday" << endl;
            break;
        case 2:
            cout << "Day: Monday" << endl;
            break;
        case 3:
            cout << "Day: Tuesday" << endl;
            break;
        case 4:
            cout << "Day: Wednesday" << endl;
            break;
        case 5:
            cout << "Day: Thursday" << endl;
            break;
        case 6:
            cout << "Day: Friday" << endl;
            break;
    }

    return 0;
}
