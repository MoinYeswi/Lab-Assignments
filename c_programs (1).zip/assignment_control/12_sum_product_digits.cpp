#include <iostream>
using namespace std;

int main()
{
    int num, sum = 0;
    long long product = 1;

    cout << "Enter a number: ";
    cin >> num;

    int temp = num;
    if (temp < 0)
        temp = -temp;

    while (temp != 0)
    {
        int digit = temp % 10;
        sum += digit;
        product *= digit;
        temp /= 10;
    }

    cout << "Sum of digits: " << sum << endl;
    cout << "Product of digits: " << product << endl;

    return 0;
}
