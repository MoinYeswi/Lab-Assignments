#include <iostream>
using namespace std;

int main()
{
    double purchase, discount, finalPrice;

    cout << "Enter purchase amount: ";
    cin >> purchase;

    discount = (purchase < 100) ? 0 :
               (purchase <= 500) ? purchase * 0.10 :
               (purchase <= 1000) ? purchase * 0.15 :
               purchase * 0.20;

    finalPrice = purchase - discount;

    cout << "Discount applied: Rs " << discount << endl;
    cout << "Final price: Rs " << finalPrice << endl;

    return 0;
}
