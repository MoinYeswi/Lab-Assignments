#include <stdio.h>

int main()
{
    int marks[5], total = 0;
    float average, percentage;

    for (int i = 0; i < 5; i++)
    {
        printf("Enter marks for subject %d: ", i + 1);
        scanf("%d", &marks[i]);
        total = total + marks[i];
    }

    average = total / 5.0;
    percentage = (total / 500.0) * 100;

    printf("Total marks: %d\n", total);
    printf("Average: %.2f\n", average);
    printf("Percentage: %.2f%%\n", percentage);

    char grade;
    if (percentage >= 90)
        grade = 'A';
    else if (percentage >= 75)
        grade = 'B';
    else if (percentage >= 60)
        grade = 'C';
    else if (percentage >= 40)
        grade = 'D';
    else
        grade = 'F';

    printf("Grade: %c\n", grade);

    return 0;
}
