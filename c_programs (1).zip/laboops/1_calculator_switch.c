#include <stdio.h>

int main()
{
    double a, b, result;
    char op;

    printf("Enter first number: ");
    scanf("%lf", &a);
    printf("Enter operator (+, -, *, /): ");
    scanf(" %c", &op);
    printf("Enter second number: ");
    scanf("%lf", &b);

    switch (op)
    {
        case '+':
            result = a + b;
            printf("Result = %.2f\n", result);
            break;
        case '-':
            result = a - b;
            printf("Result = %.2f\n", result);
            break;
        case '*':
            result = a * b;
            printf("Result = %.2f\n", result);
            break;
        case '/':
            if (b == 0)
                printf("Cannot divide by zero\n");
            else
                printf("Result = %.2f\n", a / b);
            break;
        default:
            printf("Invalid operator\n");
    }

    return 0;
}
