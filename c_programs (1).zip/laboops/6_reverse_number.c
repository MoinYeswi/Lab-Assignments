#include <stdio.h>

int main()
{
    int num, rev = 0, digit;

    printf("Enter an integer: ");
    scanf("%d", &num);

    int temp = num;
    while (temp != 0)
    {
        digit = temp % 10;
        rev = rev * 10 + digit;
        temp = temp / 10;
    }

    printf("Reversed number: %d\n", rev);

    return 0;
}
